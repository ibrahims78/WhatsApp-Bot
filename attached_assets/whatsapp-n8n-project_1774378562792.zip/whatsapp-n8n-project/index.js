// استيراد المكتبات الضرورية
const express = require('express');
const { create, createWorker } = require('@wppconnect-team/wppconnect');
const app = express();
const port = 3000;

// لتمكين معالجة بيانات JSON في طلبات POST
app.use(express.json());

// متغير لتخزين كائن العميل الخاص بـ WPPConnect
let client;

// 1. دالة تهيئة البوت والواتساب
async function startBot() {
    try {
        client = await create({
            session: 'n8n-session', // اسم الجلسة
            catchQR: (base64QR, asciiQR) => {
                console.log('رمز QR جاهز. يرجى مسحه ضوئياً:');
                console.log(asciiQR); // عرض رمز QR في الـ terminal
            },
            statusFind: (status) => {
                console.log('Status Session:', status);
                if (status === 'isLogged') {
                    console.log('البوت متصل وجاهز للاستقبال والإرسال.');
                }
            },
            // التأكد من أن جميع الوظائف غير الضرورية معطلة
            headless: true, // تشغيل المتصفح بدون واجهة
            autoClose: true
        });

        // 2. تفعيل معالج الرسائل الواردة (لتغذية n8n)
        client.onMessage(async (message) => {
            // هنا يمكنك إرسال الـ Webhook إلى n8n لاحقاً
        });

        console.log('الخادم يعمل الآن!');

    } catch (e) {
        console.error('خطأ في بدء تشغيل البوت:', e);
    }
}

// 3. نقطة نهاية API لإرسال رسالة (يستخدمها n8n للرد)
app.post('/send-text', async (req, res) => {
    const { number, message } = req.body;

    // التحقق من أن العميل متصل
    if (!client || client.status !== 'isLogged') {
        return res.status(503).json({ success: false, error: 'البوت غير متصل بالواتساب حاليًا.' });
    }

    // الدالة الحاسمة: client.sendText ترسل رسالة إلى الدردشة (Chat)
    try {
        await client.sendText(number, message);
        console.log(`تم إرسال الرد إلى: ${number}`);
        res.json({ success: true, message: 'تم إرسال الرسالة بنجاح.' });
    } catch (e) {
        console.error(`خطأ في إرسال الرسالة إلى ${number}:`, e.message);
        res.status(500).json({ success: false, error: 'فشل الإرسال.', details: e.message });
    }
});

// بدء تشغيل الخادم
app.listen(port, () => {
    console.log(`خادم البوت يستمع على المنفذ: ${port}`);
});

// بدء عملية تهيئة WPPConnect
startBot();