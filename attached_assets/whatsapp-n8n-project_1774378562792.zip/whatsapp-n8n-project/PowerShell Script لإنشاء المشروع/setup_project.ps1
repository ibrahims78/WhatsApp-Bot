# إنشاء سكريبت PowerShell لإعداد مشروع WhatsApp-n8n-Docker
# يقوم هذا السكريبت بإنشاء هيكل المجلدات والملفات المطلوبة لتشغيل البوت و n8n معاً داخل Docker.

# --- الإعدادات ---
$ProjectName = "whatsapp-n8n-project"
$TargetDirectory = Join-Path $PSScriptRoot $ProjectName

# --- محتوى الملفات ---

# محتوى package.json
$PackageJsonContent = @"
{
  "name": "whatsapp-n8n-bot",
  "version": "1.0.0",
  "description": "WhatsApp bot using WPPConnect for n8n integration.",
  "main": "index.js",
  "scripts": {
    "start": "node index.js"
  },
  "dependencies": {
    "@wppconnect-team/wppconnect": "^1.27.0",
    "express": "^4.19.2"
  }
}
"@

# محتوى Dockerfile
$DockerfileContent = @"
# استخدام صورة أساسية تحتوي على Node.js و Chromium (ضروري لـ WPPConnect)
FROM mcr.microsoft.com/playwright/node:lts

# تعيين دليل العمل
WORKDIR /usr/src/app

# نسخ ملفات المشروع
COPY package.json .
COPY index.js .

# تثبيت التبعيات
RUN npm install --unsafe-perm

# تعرض الحاوية المنفذ 3000
EXPOSE 3000

# أمر التشغيل
CMD [ "node", "index.js" ]
"@

# محتوى index.js (مع دعم إرسال النص والصور)
$IndexJsContent = @"
// استيراد المكتبات الضرورية
const express = require('express');
const { create, createWorker } = require('@wppconnect-team/wppconnect');
const app = express();
const port = 3000;

// لتمكين معالجة بيانات JSON في طلبات POST
app.use(express.json());

// متغير لتخزين كائن العميل الخاص بـ WPPConnect
let client;

// 1. دالة تهيئة البوت والواتساب
async function startBot() {
    try {
        client = await create({
            session: 'n8n-session', // اسم الجلسة
            catchQR: (base64QR, asciiQR) => {
                console.log('رمز QR جاهز. يرجى مسحه ضوئياً:');
                console.log(asciiQR); // عرض رمز QR في الـ terminal
            },
            statusFind: (status) => {
                console.log('Status Session:', status);
                if (status === 'isLogged') {
                    console.log('البوت متصل وجاهز للاستقبال والإرسال.');
                }
            },
            // التأكد من أن جميع الوظائف غير الضرورية معطلة
            headless: true, // تشغيل المتصفح بدون واجهة
            autoClose: true
        });

        // 2. تفعيل معالج الرسائل الواردة
        client.onMessage(async (message) => {
            // ملاحظة: لاستقبال الصور وتحميلها، يجب إضافة منطق هنا
            // للتحقق من message.isMedia ومن ثم استخدام client.downloadMedia
        });

        console.log('الخادم يعمل الآن!');

    } catch (e) {
        console.error('خطأ في بدء تشغيل البوت:', e);
    }
}

// 3. نقطة نهاية API لإرسال رسالة نصية (الرد الآلي)
app.post('/send-text', async (req, res) => {
    const { number, message } = req.body;

    if (!client || client.status !== 'isLogged') {
        return res.status(503).json({ success: false, error: 'البوت غير متصل بالواتساب حاليًا.' });
    }

    try {
        // client.sendText ترسل رسالة إلى الدردشة (Chat)
        await client.sendText(number, message);
        console.log(`تم إرسال الرد النصي إلى: ${number}`);
        res.json({ success: true, message: 'تم إرسال الرسالة بنجاح.' });
    } catch (e) {
        console.error(`خطأ في إرسال الرسالة النصية إلى ${number}:`, e.message);
        res.status(500).json({ success: false, error: 'فشل الإرسال.', details: e.message });
    }
});

// 4. نقطة نهاية جديدة لإرسال صورة (يمكن استدعاؤها من n8n)
// تتوقع: number (رقم المستلم) و imageUrl (رابط الصورة) و caption (النص المصاحب)
app.post('/send-image', async (req, res) => {
    const { number, imageUrl, caption } = req.body;

    if (!client || client.status !== 'isLogged') {
        return res.status(503).json({ success: false, error: 'البوت غير متصل بالواتساب حاليًا.' });
    }

    try {
        // client.sendImage يستخدم لإرسال الصور عبر رابط (URL)
        await client.sendImage(
            number,
            imageUrl,
            'image_name', // اسم الملف
            caption || 'صورة مرفقة' // النص المصاحب
        );
        console.log(`تم إرسال صورة إلى: ${number} من الرابط: ${imageUrl}`);
        res.json({ success: true, message: 'تم إرسال الصورة بنجاح.' });
    } catch (e) {
        console.error(`خطأ في إرسال الصورة إلى ${number}:`, e.message);
        res.status(500).json({ success: false, error: 'فشل إرسال الصورة.', details: e.message });
    }
});


// بدء تشغيل الخادم
app.listen(port, () => {
    console.log(`خادم البوت يستمع على المنفذ: ${port}`);
});

// بدء عملية تهيئة WPPConnect
startBot();
"@

# محتوى docker-compose.yml
$DockerComposeContent = @"
version: '3.8'

services:
  # خدمة n8n
  n8n:
    image: n8nio/n8n:latest
    container_name: n8n
    restart: always
    ports:
      - "5678:5678"
    environment:
      - N8N_HOST=localhost
      - N8N_PORT=5678
      - NODE_ENV=production
    volumes:
      - ./n8n-data:/home/node/.n8n
    networks:
      - whatsapp_n8n_network

  # خدمة بوت الواتساب
  whatsapp-bot:
    build:
      context: ./whatsapp-bot  # بناء الصورة من مجلد whatsapp-bot
      dockerfile: Dockerfile
    container_name: whatsapp-bot
    restart: always
    # نربط المنفذ 3000 إلى جهازك (لعرض QR code)
    ports:
      - "3000:3000"
    # إنشاء مجلد مستديم لحفظ بيانات جلسة الواتساب
    volumes:
      - ./whatsapp-data:/usr/src/app/tokens
    networks:
      - whatsapp_n8n_network

networks:
  whatsapp_n8n_network:
    driver: bridge
"@

# محتوى دليل التشغيل
$GuideContent = @"
# دليل إعداد وتشغيل مشروع واتساب بوت (n8n + Docker)

هذا الدليل يشرح كيفية تشغيل نظام الرد الآلي بالكامل داخل بيئة Docker الموحدة.

## المتطلبات الأساسية

1.  **Docker Desktop:** يجب أن يكون مثبتاً ويعمل على جهازك.
2.  **تنظيم الملفات:** تم إنشاء جميع المجلدات والملفات تلقائياً بواسطة سكريبت PowerShell.

## خطوات التشغيل

### الخطوة 1: تشغيل الخدمات (البناء والتشغيل)

1.  افتح موجه الأوامر (CMD أو PowerShell) على جهازك.
2.  انتقل إلى المجلد الرئيسي للمشروع الذي تم إنشاؤه:
    
    cd $TargetDirectory
    
3.  قم ببناء صور Docker وتشغيل الحاويات في الخلفية:
    
    docker-compose up -d --build
    
    * سيقوم هذا الأمر بإنشاء حاوية n8n وحاوية `whatsapp-bot`.

### الخطوة 2: ربط الواتساب (مسح رمز QR)

لأن البوت يعمل الآن داخل Docker، يجب عرض سجلاته لرؤية رمز QR.

1.  اعرض سجلات البوت:
    
    docker logs -f whatsapp-bot
    
    **ملاحظة:** قد يستغرق الأمر بضع ثوانٍ حتى يظهر رمز QR النصي.

2.  افتح تطبيق الواتساب على هاتفك وانتقل إلى **الإعدادات** > **الأجهزة المرتبطة (Linked Devices)**.

3.  امسح الرمز الذي يظهر في الـ Terminal.

4.  عند اكتمال التسجيل، ستظهر رسالة: `Status Session: isLogged`. يمكنك إيقاف عرض السجلات بالضغط على `Ctrl + C`.

### الخطوة 3: إعداد الـ Workflow في n8n

1.  افتح n8n في متصفحك: **`http://localhost:5678`**

2.  في عقدة **`HTTP Request (إرسال الرد)`**، يجب تعيين رابط الاتصال الداخلي.

    * **لإرسال نص:** استخدم الرابط `http://whatsapp-bot:3000/send-text`
    * **لإرسال صورة:** استخدم الرابط `http://whatsapp-bot:3000/send-image` (مع تمرير `imageUrl` و `caption` في جسم الطلب).

3.  **تفعيل الـ Workflow:** قم بتفعيله واختبره.

## حل مشكلة إنشاء الحالة (Status) ودعم الوسائط

* **الحالات (Statuses):** تم حل مشكلة إنشاء الحالة باستخدام الدالة **`client.sendText`** لرسائل الدردشة.
* **الوسائط:** يدعم البوت الآن نقطة النهاية **`/send-image`** لإرسال الصور التي يتم سحبها من رابط (URL) عبر n8n.
"@

# --- تنفيذ الإنشاء ---

Write-Host "جاري إعداد هيكل المشروع $ProjectName..."

# إنشاء المجلد الرئيسي
New-Item -ItemType Directory -Path $TargetDirectory -Force | Out-Null
Set-Location $TargetDirectory

# إنشاء مجلد البوت الفرعي
$BotFolder = Join-Path $TargetDirectory "whatsapp-bot"
New-Item -ItemType Directory -Path $BotFolder -Force | Out-Null

# كتابة ملفات البوت
Set-Content -Path (Join-Path $BotFolder "package.json") -Value $PackageJsonContent -Encoding UTF8
Set-Content -Path (Join-Path $BotFolder "Dockerfile") -Value $DockerfileContent -Encoding UTF8
Set-Content -Path (Join-Path $BotFolder "index.js") -Value $IndexJsContent -Encoding UTF8

# كتابة ملفات Docker Compose والدليل
Set-Content -Path (Join-Path $TargetDirectory "docker-compose.yml") -Value $DockerComposeContent -Encoding UTF8
Set-Content -Path (Join-Path $TargetDirectory "setup_guide.txt") -Value $GuideContent -Encoding UTF8

Write-Host "تم إكمال إعداد المشروع بنجاح."
Write-Host "--------------------------------------------------------"
Write-Host "المشروع جاهز في المسار:"
Write-Host $TargetDirectory
Write-Host "يرجى الانتقال إلى هذا المسار واتباع الخطوات في ملف setup_guide.txt لبدء التشغيل."
Write-Host "--------------------------------------------------------"