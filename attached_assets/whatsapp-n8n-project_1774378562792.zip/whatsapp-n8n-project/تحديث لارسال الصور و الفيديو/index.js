// استيراد المكتبات الضرورية
const express = require('express');
const { create, createWorker } = require('@wppconnect-team/wppconnect');
const app = express();
const port = 3000;

// لتمكين معالجة بيانات JSON في طلبات POST
app.use(express.json());

// متغير لتخزين كائن العميل الخاص بـ WPPConnect
let client;

// 1. دالة تهيئة البوت والواتساب
async function startBot() {
    try {
        client = await create({
            session: 'n8n-session', // اسم الجلسة
            catchQR: (base64QR, asciiQR) => {
                console.log('رمز QR جاهز. يرجى مسحه ضوئياً:');
                console.log(asciiQR); // عرض رمز QR في الـ terminal
            },
            statusFind: (status) => {
                console.log('Status Session:', status);
                if (status === 'isLogged') {
                    console.log('البوت متصل وجاهز للاستقبال والإرسال.');
                }
            },
            // التأكد من أن جميع الوظائف غير الضرورية معطلة
            headless: true, // تشغيل المتصفح بدون واجهة
            autoClose: true
        });

        // 2. تفعيل معالج الرسائل الواردة
        client.onMessage(async (message) => {
            // ملاحظة: لاستقبال الصور وتحميلها، يجب إضافة منطق هنا
            // للتحقق من message.isMedia ومن ثم استخدام client.downloadMedia
        });

        console.log('الخادم يعمل الآن!');

    } catch (e) {
        console.error('خطأ في بدء تشغيل البوت:', e);
    }
}

// 3. نقطة نهاية API لإرسال رسالة نصية (الرد الآلي)
app.post('/send-text', async (req, res) => {
    const { number, message } = req.body;

    if (!client || client.status !== 'isLogged') {
        return res.status(503).json({ success: false, error: 'البوت غير متصل بالواتساب حاليًا.' });
    }

    try {
        // client.sendText ترسل رسالة إلى الدردشة (Chat)
        await client.sendText(number, message);
        console.log(`تم إرسال الرد النصي إلى: ${number}`);
        res.json({ success: true, message: 'تم إرسال الرسالة بنجاح.' });
    } catch (e) {
        console.error(`خطأ في إرسال الرسالة النصية إلى ${number}:`, e.message);
        res.status(500).json({ success: false, error: 'فشل الإرسال.', details: e.message });
    }
});

// 4. نقطة نهاية جديدة لإرسال صورة (يمكن استدعاؤها من n8n)
// تتوقع: number (رقم المستلم) و imageUrl (رابط الصورة) و caption (النص المصاحب)
app.post('/send-image', async (req, res) => {
    const { number, imageUrl, caption } = req.body;

    if (!client || client.status !== 'isLogged') {
        return res.status(503).json({ success: false, error: 'البوت غير متصل بالواتساب حاليًا.' });
    }

    try {
        // client.sendImage يستخدم لإرسال الصور عبر رابط (URL)
        await client.sendImage(
            number,
            imageUrl,
            'image_name', // اسم الملف
            caption || 'صورة مرفقة' // النص المصاحب
        );
        console.log(`تم إرسال صورة إلى: ${number} من الرابط: ${imageUrl}`);
        res.json({ success: true, message: 'تم إرسال الصورة بنجاح.' });
    } catch (e) {
        console.error(`خطأ في إرسال الصورة إلى ${number}:`, e.message);
        res.status(500).json({ success: false, error: 'فشل إرسال الصورة.', details: e.message });
    }
});


// بدء تشغيل الخادم
app.listen(port, () => {
    console.log(`خادم البوت يستمع على المنفذ: ${port}`);
});

// بدء عملية تهيئة WPPConnect
startBot();